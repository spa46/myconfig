pushd folder3
find . -maxdepth 1 ! -name '.*' \
                   ! -name '1'  \
                   ! -name '2'  \
			      | \
		   xargs rm -rf
popd
